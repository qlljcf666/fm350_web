# FG360-EAU 管理 1.1.0

适用于 Fibocom FG360-EAU (MT6890) 的 OpenWrt LuCI 管理与调试插件。

基于 luci-app-rg620t-lock 架构，针对 FG360 的 MediaTek AT 命令体系完全重写。

## 实测验证（固件 81104.7000.00.05.01.02）

已在真实设备上验证通过：

- ✅ 设备识别：FG360-EAU / Fibocom Wireless Inc.
- ✅ 网络模式读取：AT+GTRAT → 自动 / NR Only 等
- ✅ 频段读取：AT+GTACT → LTE B1-B43 + NR n1-n79
- ✅ 信号：AT+CESQ → SS-RSRP/SS-RSRQ/SS-SINR（0.5dB 步进换算）
- ✅ 当前小区：AT+GTCAINFO → PCC（频段/PCI/ARFCN/RSRP）
- ✅ 邻区扫描：AT+GTCCINFO → 服务小区 + 最多 10 个邻区（hex 字段自动转换）
- ✅ 注册状态：AT+PSRAT / C5GREG / CEREG
- ✅ 小区锁定：AT+GTCELLLOCK（读/写/解锁，60 秒确认保护）
- ✅ 改串（IMEI 写入）：AT+EGMR（Luhn 校验 + 双重确认 + 令牌 + 读回验证）
- ✅ IMEI 只读信息（CGSN + Luhn 校验）
- ✅ AT 调试台：通过 ATCI 通道，干净无噪音
- ✅ LuCI 页面与 API：HTTP 200，JSON 正常

## ⚠️ 关键技术发现：AT 通道

FG360-EAU 的 `mipc_wan_cli`（CCCI 通道）对部分命令存在超时问题：
`GTCAINFO?`、`PSRAT`、`GTCCINFO?` 在 mipc_wan_cli 上**无响应**。

**解决方案**：设备的 `atcid` 守护进程监听 **TCP 17171** 端口（ATCI 通道），
通过该端口发送 AT 命令全部正常。插件通过 `/usr/bin/fg360-at.lua`
（nixio socket）使用该通道，失败时自动回退 mipc_wan_cli。

## 主要功能

- LTE/NR 频段实时读取与设置（AT+GTACT）
- 网络模式切换：自动 / LTE Only / NR Only / NR+LTE（AT+GTRAT）
- EARFCN/NARFCN 与 PCI 锁定、60 秒自动解锁保护（AT+GTCELLLOCK）
- **当前服务小区常驻**（AT+GTCAINFO + AT+GTCCINFO，含 RSRP/RSRQ/SINR）
- **邻区扫描常驻**（AT+GTCCINFO，含同频/异频识别、频段推算）
- **邻区一键填入锁定**（扫描结果直接联动锁区表单）
- **改串（IMEI 写入）**（AT+EGMR，4 层安全保护）
- 引导式 AT 调试窗口和操作日志
- IMEI 只读信息（读取 + Luhn 校验 + 复制）

## 频段说明

FG360-EAU 使用 Fibocom 专有的 GTACT 频段编码：
- LTE: 100 + 频段号（如 B1 = 101, B28 = 128）
- NR: "50" + 频段号（如 n1 = 501, n78 = 5078）
- GTCCINFO 的 band 字段同为 GTACT 编码，页面自动转换
- 邻区无 band 字段时按 3GPP 38.101/36.101 ARFCN 范围推算

## 目录结构

```
luci-app-fg360-lock/
├── Makefile                       # OpenWrt SDK 构建
├── build-ipk.sh                   # 独立 ipk 构建脚本
├── README.md
├── luasrc/
│   ├── controller/fg360_lock.lua  # LuCI HTTP API 控制器
│   └── view/fg360_lock/index.htm  # 前端页面
└── root/usr/bin/
    ├── fg360-lock                 # 后端主脚本
    └── fg360-at.lua               # ATCI TCP 17171 AT 发送器
```

## 安装

```sh
opkg install luci-app-fg360-lock_1.1.0-1_all.ipk
```

## 手动构建

```sh
chmod +x build-ipk.sh
./build-ipk.sh
```

## 依赖

- luci-base, luci-compat
- /usr/bin/mipc_wan_cli（回退通道）
- atcid 守护进程（TCP 17171，主通道，OpenWrt 系统自带）
