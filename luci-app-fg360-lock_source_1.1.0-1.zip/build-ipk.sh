#!/bin/sh
set -eu

PKG_NAME="luci-app-fg360-lock"
VERSION="1.1.0-1"
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
BUILD="${TMPDIR:-/tmp}/${PKG_NAME}-build-$$"
OUT="${1:-$HERE}"
trap 'rm -rf "$BUILD"' EXIT INT TERM

mkdir -p "$BUILD/root/CONTROL" "$BUILD/tmp" \
  "$BUILD/root/usr/lib/lua/luci/controller" \
  "$BUILD/root/usr/lib/lua/luci/view/fg360_lock" \
  "$BUILD/root/usr/bin" "$OUT"

cp "$HERE/luasrc/controller/fg360_lock.lua" "$BUILD/root/usr/lib/lua/luci/controller/"
cp "$HERE/luasrc/view/fg360_lock/index.htm" "$BUILD/root/usr/lib/lua/luci/view/fg360_lock/"
cp "$HERE/root/usr/bin/fg360-lock" "$BUILD/root/usr/bin/"
cp "$HERE/root/usr/bin/fg360-at.lua" "$BUILD/root/usr/bin/"
chmod 0755 "$BUILD/root/usr/bin/fg360-lock"
chmod 0755 "$BUILD/root/usr/bin/fg360-at.lua"

cat > "$BUILD/root/CONTROL/control" <<CONTROL
Package: $PKG_NAME
Version: $VERSION
Architecture: all
Maintainer: Kun for FG360-EAU
Depends: luci-base, luci-compat
Section: luci
Priority: optional
Description: FG360-EAU (MT6890) management LuCI plugin with direct AT command band control, LTE/NR band selection, SA/NSA mode switching, EARFCN/PCI locking, quick overview monitoring, IMEI read-only information and a guided AT debug console.
CONTROL

cat > "$BUILD/root/CONTROL/postinst" <<'POSTINST'
#!/bin/sh
[ -n "$IPKG_INSTROOT" ] && exit 0
[ -x /usr/bin/mipc_wan_cli ] || echo "警告：未找到 /usr/bin/mipc_wan_cli，插件暂时无法工作。"
rm -f /tmp/luci-indexcache
rm -rf /tmp/luci-modulecache /tmp/luci-templatecache
exit 0
POSTINST

cat > "$BUILD/root/CONTROL/prerm" <<'PRERM'
#!/bin/sh
rm -f /tmp/fg360-lock-pending-* 2>/dev/null
rm -rf /var/lock/fg360-lock.lock 2>/dev/null
exit 0
PRERM

cat > "$BUILD/root/CONTROL/postrm" <<'POSTRM'
#!/bin/sh
[ -n "$IPKG_INSTROOT" ] && exit 0
rm -f /tmp/luci-indexcache
rm -rf /tmp/luci-modulecache /tmp/luci-templatecache
exit 0
POSTRM
chmod 0755 "$BUILD/root/CONTROL/postinst" \
  "$BUILD/root/CONTROL/prerm" "$BUILD/root/CONTROL/postrm"

(
  cd "$BUILD/root"
  tar --format=gnu --numeric-owner --owner=0 --group=0 --sort=name --mtime='@0' \
      --exclude='./CONTROL' -cpf - . | gzip -n -9 > "$BUILD/tmp/data.tar.gz"
)
printf 'Installed-Size: %s\n' "$(stat -c '%s' "$BUILD/tmp/data.tar.gz")" >> "$BUILD/root/CONTROL/control"
(
  cd "$BUILD/root/CONTROL"
  tar --format=gnu --numeric-owner --owner=0 --group=0 --sort=name --mtime='@0' \
      -cpf - . | gzip -n -9 > "$BUILD/tmp/control.tar.gz"
)
printf '2.0\n' > "$BUILD/tmp/debian-binary"
(
  cd "$BUILD/tmp"
  tar --format=gnu --numeric-owner --owner=0 --group=0 --sort=name --mtime='@0' \
      -cpf - ./debian-binary ./data.tar.gz ./control.tar.gz | gzip -n -9 \
      > "$OUT/${PKG_NAME}_${VERSION}_all.ipk"
)
printf 'Built: %s\n' "$OUT/${PKG_NAME}_${VERSION}_all.ipk"
