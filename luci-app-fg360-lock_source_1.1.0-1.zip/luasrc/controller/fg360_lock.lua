module("luci.controller.fg360_lock", package.seeall)

function index()
    local fs = require "nixio.fs"
    if not fs.access("/usr/bin/fg360-lock") then
        return
    end

    local page = entry(
        {"admin", "network", "fg360_lock"},
        template("fg360_lock/index"),
        _("FG360 管理"),
        92
    )
    page.dependent = false

    local api = entry(
        {"admin", "network", "fg360_lock", "api"},
        call("action_api")
    )
    api.leaf = true
end

local function shellquote(value)
    value = tostring(value or "")
    return "'" .. value:gsub("'", "'\\''") .. "'"
end

local function json_reply(object)
    local http = require "luci.http"
    local jsonc = require "luci.jsonc"
    http.prepare_content("application/json")
    http.write(jsonc.stringify(object))
end

local function valid_uint(value, maximum)
    value = tostring(value or "")
    if not value:match("^%d+$") then
        return nil
    end
    local number = tonumber(value)
    if not number or number < 0 or (maximum and number > maximum) then
        return nil
    end
    return tostring(math.floor(number))
end

local function run_backend(arguments)
    local sys = require "luci.sys"
    local fs = require "nixio.fs"
    local nixio = require "nixio"

    local temp = string.format(
        "/tmp/fg360-lock-api-%d-%d",
        nixio.getpid(),
        math.random(100000, 999999)
    )

    local command = "/usr/bin/fg360-lock"
    for _, argument in ipairs(arguments) do
        command = command .. " " .. shellquote(argument)
    end
    command = command .. " >" .. shellquote(temp) .. " 2>&1"

    local code = sys.call(command)
    local output = fs.readfile(temp) or ""
    fs.remove(temp)

    return code, output
end

local function reject(message)
    json_reply({ ok = false, code = 400, output = message })
end

function action_api()
    local http = require "luci.http"
    local action = tostring(http.formvalue("action") or "")
    local args = nil

    if action == "status" then
        args = { "status" }

    elseif action == "quick_overview" then
        args = { "quick-overview" }

    elseif action == "device_info" then
        args = { "device-info" }

    elseif action == "radio_status" then
        args = { "radio-status" }

    elseif action == "mode_status" then
        args = { "mode-status" }

    elseif action == "imei_info" then
        args = { "imei-info" }

    elseif action == "reconnect_radio" then
        args = { "reconnect-radio" }

    elseif action == "at_send" then
        local command = tostring(http.formvalue("command") or "")
        if #command == 0 or #command > 256 then
            return reject("AT 命令长度必须为 1-256 个字符")
        end
        if command:find("[\r\n]") then
            return reject("一次只能发送一条 AT 命令")
        end
        if command:find(";", 1, true) then
            return reject("一次只能发送一条 AT 命令，不能使用分号串联")
        end
        if not command:upper():match("^AT") then
            return reject("命令必须以 AT 开头")
        end
        args = { "at-send", command }

    elseif action == "cell_info" then
        args = { "cell-info" }

    elseif action == "band_status" then
        args = { "band-status" }

    elseif action == "lock_status" then
        args = { "lock-status" }

    elseif action == "log" then
        args = { "log" }

    elseif action == "unlock_cell" then
        args = { "unlock-cell", "web" }

    elseif action == "confirm" then
        local token = tostring(http.formvalue("token") or "")
        if not token:match("^[A-Za-z0-9_-]+$") or #token > 96 then
            return reject("确认令牌无效")
        end
        args = { "confirm", token }

    elseif action == "set_network_mode" then
        local mode = tostring(http.formvalue("mode") or "")
        local reconnect = tostring(http.formvalue("reconnect") or "1")
        if mode ~= "auto" and mode ~= "lte" and mode ~= "nr" and mode ~= "nr_lte" then
            return reject("网络模式无效")
        end
        reconnect = reconnect == "0" and "0" or "1"
        args = { "set-network-mode", mode, reconnect }

    elseif action == "imei_token" then
        args = { "imei-token" }

    elseif action == "set_imei" then
        local imei = tostring(http.formvalue("imei") or "")
        local token = tostring(http.formvalue("token") or "")
        if not imei:match("^%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d$") then
            return reject("IMEI 必须为 15 位数字")
        end
        if not token:match("^[A-Za-z0-9]+$") or #token > 64 then
            return reject("确认令牌无效")
        end
        args = { "set-imei", imei, token }

    elseif action == "lock_cell" then
        local rat = valid_uint(http.formvalue("rat"), 11)
        local earfcn = valid_uint(http.formvalue("earfcn"), 4294967295)
        local pci = valid_uint(http.formvalue("pci"), 1007)
        local lock_type = valid_uint(http.formvalue("lock_type"), 2)
        local protect = valid_uint(http.formvalue("protect"), 1)

        if rat ~= "0" and rat ~= "1" then
            return reject("制式只能选择 LTE 或 NR")
        end
        if not earfcn then
            return reject("EARFCN/NARFCN 必须为 0-4294967295 的整数")
        end
        if lock_type ~= "0" and lock_type ~= "1" then
            return reject("锁定类型无效")
        end
        if lock_type == "0" and not pci then
            return reject("锁 PCI 时，PCI 必须为 0-1007 的整数")
        end
        pci = pci or "0"
        protect = protect == "0" and "0" or "1"
        args = { "lock-cell", rat, earfcn, pci, lock_type, protect }

    elseif action == "set_bands" then
        local rat = tostring(http.formvalue("rat") or "")
        local bands = tostring(http.formvalue("bands") or "")
        if rat ~= "lte" and rat ~= "nr" then
            return reject("频段制式无效")
        end
        if not bands:match("^%d+[,%d]*$") or #bands > 256 then
            return reject("频段列表格式错误")
        end
        local reconnect = tostring(http.formvalue("reconnect") or "0")
        reconnect = reconnect == "1" and "1" or "0"
        args = { "set-bands", rat, bands, reconnect }

    elseif action == "restore_bands" then
        local target = tostring(http.formvalue("target") or "")
        if target ~= "lte" and target ~= "nr" and target ~= "all" then
            return reject("恢复目标无效")
        end
        args = { "restore-bands", target }

    else
        return reject("未知操作")
    end

    local code, output = run_backend(args)
    json_reply({
        ok = (code == 0),
        code = code,
        output = output
    })
end
